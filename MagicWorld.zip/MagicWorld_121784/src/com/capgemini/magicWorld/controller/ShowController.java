package com.capgemini.magicWorld.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.magicWorld.dto.BookTicket;
import com.capgemini.magicWorld.exception.BookException;
import com.capgemini.magicWorld.service.ShowService;
import com.capgemini.magicWorld.service.ShowServiceImpl;

@WebServlet("*.do")
public class ShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ShowService service;
	private RequestDispatcher dispatcher;

	public void init(ServletConfig config) throws ServletException {
		service=new ShowServiceImpl();
	}
	
	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String path=request.getServletPath();
		if(path.equals("/*.do")){
			List<BookTicket> myList=new ArrayList<>();
			try {
				myList=service.showDetails();
				
				HttpSession session=request.getSession(true);
				session.setAttribute("data",myList);
				dispatcher=request.getRequestDispatcher("ShowDetails.jsp");
				dispatcher.forward(request, response);
			} catch (BookException e) {
				//e.printStackTrace();
				request.setAttribute("errorMsg","No shows Available");
				dispatcher=request.getRequestDispatcher("Error.jsp");
				dispatcher.forward(request, response);
			}
			
			
		}
		
		else
			if(path.equals("/bookForm.do")){
				dispatcher=request.getRequestDispatcher("BookingForm.jsp");
				dispatcher.forward(request, response);
				
			}
			else
				if(path.equals("/bookNow.do")){
					
					String showName=request.getParameter("showName");
					
					String custName=request.getParameter("custName");
					boolean name=service.isValidName(custName);
					if(!name){
						request.setAttribute("errorMsg","Invalid name");
						dispatcher=request.getRequestDispatcher("Error.jsp");
						dispatcher.forward(request, response);
					}
					
					String mobile=request.getParameter("mobile");
					boolean mNo=service.isValidMobile(mobile);
					if(!mNo){
						request.setAttribute("errorMsg","Invalid mobile number");
						dispatcher=request.getRequestDispatcher("Error.jsp");
						dispatcher.forward(request, response);
					}
					
					int seats=Integer.parseInt(request.getParameter("seats"));
					boolean seat=false;
					try {
						seat = service.isValidSeat(seats,showName);
					} catch (BookException e1) {
						e1.printStackTrace();
					}
					if(!seat){
						request.setAttribute("errorMsg","Invalid number of seat");
						dispatcher=request.getRequestDispatcher("Error.jsp");
						dispatcher.forward(request, response);
					}
					
					
					
					boolean showStatus=false;
					try {
						showStatus=service.updateSeats(showName,seats);
						BookTicket bt=new BookTicket();
						bt.setShowName(showName);
						bt.setCustName(custName);
						bt.setMobile(mobile);
						bt.setSeats(seats);
						HttpSession session=request.getSession(true);
						session.setAttribute("book",bt);
						
						dispatcher=request.getRequestDispatcher("Success.jsp");
						dispatcher.forward(request, response);
					} catch (BookException e) {
						//e.printStackTrace();
						request.setAttribute("errorMsg","Invalid number of seat");
						dispatcher=request.getRequestDispatcher("Error.jsp");
						dispatcher.forward(request, response);
					}
				}
				else
					if(path.equals("/home.do")){
						HttpSession session=request.getSession(false);
						session.invalidate();
						dispatcher=request.getRequestDispatcher("index.jsp");
						dispatcher.forward(request, response);
					}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

}
