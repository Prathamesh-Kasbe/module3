package com.capgemini.magicWorld.service;

import java.util.List;

import com.capgemini.magicWorld.dto.BookTicket;
import com.capgemini.magicWorld.exception.BookException;

public interface ShowService {

	List<BookTicket> showDetails()throws BookException;
	boolean updateSeats(String showName,int seats)throws BookException;
	boolean isValidName(String custName);
	boolean isValidMobile(String mobile);
	boolean isValidSeat(int seats,String showName) throws BookException;
	
	
}
