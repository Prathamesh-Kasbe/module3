package com.capgemini.magicWorld.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.magicWorld.dao.ShowDao;
import com.capgemini.magicWorld.dao.ShowDaoImpl;
import com.capgemini.magicWorld.dto.BookTicket;
import com.capgemini.magicWorld.exception.BookException;

public class ShowServiceImpl implements ShowService {

	private ShowDao dao;
	public ShowServiceImpl() {
		dao=new ShowDaoImpl();
	}

	@Override
	public List<BookTicket> showDetails() throws BookException {
		
		return dao.showDetails();
	}


	@Override
	public boolean updateSeats(String showName,int seats) throws BookException {
		
		return dao.updateSeats(showName,seats);
	}

	@Override
	public boolean isValidName(String custName) {
		Pattern pattern=Pattern.compile("[A-Z][a-z]{15}");
		Matcher matcher=pattern.matcher(custName);
		if(matcher.matches()){
			return true;
		}
		else{		
		return false;
		}
	}

	@Override
	public boolean isValidMobile(String mobile) {
		Pattern pattern=Pattern.compile("[7-9][0-9]{9}");
		Matcher matcher=pattern.matcher(mobile);
		if(matcher.matches()){
			return true;
		}
		else{		
		return false;
		}
	}

	@Override
	public boolean isValidSeat(int seats,String showName) throws BookException {
		int availableSeats=dao.checkAvailabeSeats(showName);
		if(seats<=availableSeats || seats>0){
		return true;
		}
		return false;
	}
}
