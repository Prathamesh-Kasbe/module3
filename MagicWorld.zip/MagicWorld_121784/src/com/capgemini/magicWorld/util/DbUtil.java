package com.capgemini.magicWorld.util;

import java.sql.Connection;
import java.sql.SQLException;

import com.capgemini.magicWorld.exception.BookException;

import oracle.jdbc.pool.OracleDataSource;

public class DbUtil {
	
	
	private OracleDataSource dataSource;
	   public DbUtil() throws BookException{
			
		}
		
		public Connection getConnection() throws BookException{
			try {
				dataSource=new OracleDataSource();
				dataSource.setURL("jdbc:oracle:thin:@10.125.6.62:1521:ORCL11G");
				dataSource.setUser("labg104trg12");
				dataSource.setPassword("labg104oracle");
				dataSource.setDriverType("oracle");
				return dataSource.getConnection();
			}catch (SQLException e) {
				//e.printStackTrace();
				throw new BookException("Failed to connect"+e);
			}
			
		}

		@Override
		protected void finalize() throws Throwable {
			dataSource.close();
			super.finalize();
		}

}
