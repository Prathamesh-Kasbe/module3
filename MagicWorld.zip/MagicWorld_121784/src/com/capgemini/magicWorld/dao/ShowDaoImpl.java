package com.capgemini.magicWorld.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.magicWorld.dto.BookTicket;
import com.capgemini.magicWorld.exception.BookException;
import com.capgemini.magicWorld.util.DbUtil;

public class ShowDaoImpl implements ShowDao {
    
	private DbUtil util;
	public ShowDaoImpl() {
		try {
			util=new DbUtil();
		} catch (BookException e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<BookTicket> showDetails() throws BookException {
		Connection connect=null;
		PreparedStatement pst=null;
		
		String query="SELECT SHOWNAME,LOCATION,SHOWDATE,PRICETICKET,AVSEATS FROM SHOWDETAILS";
		List<BookTicket> myList=new ArrayList<>();
		try{
			connect=util.getConnection();
			pst=connect.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()){
				BookTicket book=new BookTicket();
				book.setShowName(rs.getString("SHOWNAME"));
				book.setLocation(rs.getString("LOCATION"));
				book.setDate(rs.getString("SHOWDATE"));
				book.setPrice(rs.getFloat("PRICETICKET"));
				int availableSeats=rs.getInt("AVSEATS");
				book.setAvailableSeats(availableSeats);
				if(availableSeats>0){
					book.setBookStatus("Book Now");
				}
				else{
					book.setBookStatus("Sold");
				}
				myList.add(book);
				
			}
			return myList;
		}catch(SQLException e){
			//e.printStackTrace();
			throw new BookException("JDBC failed"+e);			
		}finally{
			try {
				if(pst!=null){
					pst.close();
				}
				if(connect!=null){
					connect.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}

	@Override
	public boolean updateSeats(String showName,int seats) throws BookException {
		Connection connect=null;
		PreparedStatement pst=null;
		
		String query="UPDATE SHOWDETAILS SET AVSEATS=AVSEATS-? WHERE SHOWNAME=?";
		try {
			connect=util.getConnection(); 
			pst=connect.prepareStatement(query);
			pst.setInt(1,seats);
			pst.setString(2,showName);
		int rec=pst.executeUpdate();
		if(rec>0){
			return true;
		}
		}catch (SQLException e) {
			//e.printStackTrace();
			throw new BookException("Data not Updated"+e);
		}finally{
			try {
				if(pst!=null){
					pst.close();
				}
				if(connect!=null){
					connect.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return false;
	}
	
	@Override
	public int checkAvailabeSeats(String showName) throws BookException {
		Connection connect=null;
		PreparedStatement pst=null;
		
		String query=null;
		
		query="SELECT AVSEATS FROM SHOWDETAILS WHERE SHOWNAME=?";
		
		int availableSeats=0;
		try {
			connect=util.getConnection(); 
			pst=connect.prepareStatement(query);
			pst.setString(1,showName);
		ResultSet res=pst.executeQuery();
		while(res.next()){
		availableSeats=res.getInt("AVSEATS");
		}
		}catch (SQLException e) {
			//e.printStackTrace();
			throw new BookException("Seat not available for "+showName);
		}finally{
			try {
				connect.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return availableSeats;
	}

}
