package com.capgemini.magicWorld.dao;

import java.util.List;

import com.capgemini.magicWorld.dto.BookTicket;
import com.capgemini.magicWorld.exception.BookException;

public interface ShowDao {

	List<BookTicket> showDetails()throws BookException;
	boolean updateSeats(String showName,int seats)throws BookException;
	int checkAvailabeSeats(String showName) throws BookException;
}
